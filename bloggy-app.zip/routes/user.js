import express from "express";
import User from "../models/users.js";

const router=express.Router();
router.get("/singin",(req,resp)=>{
    return resp.render("singin")
});

router.get("/singup",(req,resp)=>{
    return resp.render("singup")
});

router.post("/singup",async(req,resp)=>{
     const { fullName, email, password } = req.body;
     await User.create({
       fullName,
       email,
       password,
     });
     return resp.redirect("/");
   });
   
router.post("/singin", async(req,resp)=>{
    const{email,password}=req.body;
    try{

        const token=await User.matchPasswordAndGenerateToken(email,password,);
        return resp.cookie("token", token).redirect("/");
    }
    catch (error) {
    return resp.render("singin", {
      error: "Incorrect Email or Password",
    });
  }
});
router.get("/logout", (req, resp) => {
  resp.clearCookie("token").redirect("/");
});

    // console.log("User",user);
    // return resp.redirect("home");
// })


export default router;