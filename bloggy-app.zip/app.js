import dotenv from "dotenv";
dotenv.config();
import path from"path";
import express from "express";
 import userRoute from "./routes/user.js";
 import mongoose from "mongoose";
 import cookieParser from "cookie-parser";
import checkForAuthenticationCookie from "./middlewares/authentication.js";

// const Blog = require("./models/blog");

import Blog from "./models/blogs.js";

// const userRoute = require("./routes/user");
// import userRoute from "./routes/user.js";
// const blogRoute = require("./routes/blog");
import blogRoute from "./routes/blog.js";




const app= express();
const port= process.env.port;

mongoose.connect(process.env.MONGO_URL).then((e)=>console.log("mongo db connected"));

app.set(`view engine`,`ejs`);
app.set(`views`, path.resolve("./views"));

app.use(express.urlencoded({extended:false}));
app.use(cookieParser());
app.use(checkForAuthenticationCookie("token"));
app.use(express.static(path.resolve("./public")));


app.get("/", async (req, res) => {
  const allBlogs = await Blog.find({});
  res.render("home", {
    user: req.user,
    blogs: allBlogs,
  });
});
app.use("/user",userRoute);
app.use("/blog",blogRoute);


app.listen(port,()=>console.log(`server started ap port:${port}`))